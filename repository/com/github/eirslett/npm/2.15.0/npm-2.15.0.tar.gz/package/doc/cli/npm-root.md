npm-root(1) -- Display npm root
===============================

## SYNOPSIS

    npm root

## DESCRIPTION

Print the effective `node_modules` folder to standard out.

## SEE ALSO

* npm-prefix(1)
* npm-bin(1)
* npm-folders(5)
* npm-config(1)
* npm-config(7)
* npmrc(5)
